"""Regressões: login, CRM, isolamento dos disparos, migração e banco vazio."""
import sqlite3
from datetime import date
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
import app as backend

@pytest.fixture
def c(tmp_path,monkeypatch):
    monkeypatch.setattr(backend,'DB_PATH',tmp_path/'pulso-test.db')
    monkeypatch.delenv('APP_SETUP_KEY',raising=False)
    with TestClient(backend.app) as client:yield client

def auth(c):
    r=c.post('/api/setup',json={'email':'crm@exemplo.com','password':'Senha-Forte-CRM-2026'})
    assert r.status_code==200, r.text
    r=c.post('/api/login',json={'email':'crm@exemplo.com','password':'Senha-Forte-CRM-2026'})
    assert r.status_code==200, r.text
    return {'X-CSRF-Token':r.json()['csrf']}

def create(c,h,**kwargs):
    d={'name':'Agência Solaris','email':'solaris@exemplo.com','company':'Solaris'};d.update(kwargs)
    r=c.post('/api/crm/contacts',headers=h,json=d)
    assert r.status_code==200,r.text
    return r.json()['id']

def test_initial_database_is_empty(c):
    assert c.get('/api/setup').json()['required'] is True
    h=auth(c)
    d=c.get('/api/crm/summary').json()
    assert d['total_contacts']==d['accepted']==d['deals_closed']==d['active_monthly_cents']==0
    assert c.get('/api/crm/deals').json()['items']==[]
    assert c.get('/api/crm/contacts').json()['items']==[]
    assert c.get('/api/health').json()['messaging'] is False

def test_crm_requires_login_and_csrf(c):
    assert c.get('/api/crm/contacts').status_code==401
    h=auth(c)
    assert c.post('/api/crm/contacts',json={'name':'Pessoa Teste','email':'teste@site.com'}).status_code==403
    assert c.post('/api/crm/contacts',headers=h,json={'name':'Pessoa Teste','email':'teste@site.com'}).status_code==200

def test_contact_and_response(c):
    h=auth(c);cid=create(c,h)
    assert c.get('/api/crm/summary').json()['pending']==1
    r=c.put(f'/api/crm/contacts/{cid}',headers=h,json={'name':'Agência Solaris','email':'solaris@exemplo.com','proposal_status':'aceitou','pipeline_stage':'proposta'})
    assert r.status_code==200,r.text
    assert c.get('/api/crm/summary').json()['accepted']==1
    assert c.get('/api/crm/contacts',params={'proposal':'aceitou'}).json()['items'][0]['id']==cid

def test_deals_values_and_status(c):
    h=auth(c);cid=create(c,h)
    first=c.post(f'/api/crm/contacts/{cid}/deals',headers=h,json={'plan_name':'Social Media 360','monthly_value':'1800.00','closed_date':'2026-10-10'})
    assert first.status_code==200,first.text
    second=c.post(f'/api/crm/contacts/{cid}/deals',headers=h,json={'plan_name':'Tráfego Pago','monthly_value':'450,50','closed_date':'2026-10-10'})
    assert second.status_code==200,second.text
    report=c.get('/api/crm/summary').json()
    assert report['active_monthly_cents']==225050 and report['deals_closed']==2
    assert c.get('/api/crm/deals').json()['items'][0]['plan_name']=='Tráfego Pago'
    r=c.put(f'/api/crm/deals/{second.json()["id"]}',headers=h,json={'plan_name':'Tráfego Pago','monthly_value':'450.50','closed_date':'2026-10-10','status':'cancelado'})
    assert r.status_code==200,r.text
    assert c.get('/api/crm/summary').json()['active_monthly_cents']==180000

def test_delete_contact_guard(c):
    h=auth(c);cid=create(c,h)
    deal=c.post(f'/api/crm/contacts/{cid}/deals',headers=h,json={'plan_name':'Gestão Completa','monthly_value':'2000','closed_date':'2026-10-10'}).json()['id']
    assert c.delete(f'/api/crm/contacts/{cid}',headers=h).status_code==409
    assert c.delete(f'/api/crm/deals/{deal}',headers=h).status_code==200
    assert c.delete(f'/api/crm/contacts/{cid}',headers=h).status_code==200
    assert c.get('/api/crm/summary').json()['total_contacts']==0

def test_followup_and_history(c):
    h=auth(c);cid=create(c,h,next_followup_at=date.today().isoformat(),pipeline_stage='reuniao')
    assert c.get('/api/crm/summary').json()['followups_due']==1
    assert c.post(f'/api/crm/contacts/{cid}/history',headers=h,json={'description':'Cliente solicitou proposta.'}).status_code==200
    assert len(c.get(f'/api/crm/contacts/{cid}').json()['history'])==1

def test_csv_import_duplicate(c):
    h=auth(c)
    csv='nome;email;empresa;etapa;proposta\nAna;ana@example.com;Acme;novo;pendente\nAna;ana@example.com;Acme;novo;pendente\nInvalido;;;;erro\n'
    result=c.post('/api/crm/import',headers=h,json={'csv':csv})
    assert result.status_code==200,result.text
    assert result.json()['added']==1 and result.json()['duplicates']==1 and result.json()['invalid']==1

def test_no_messaging_routes(c,monkeypatch):
    h=auth(c)
    routes={getattr(r,'path','') for r in backend.app.routes}
    assert '/api/campaigns' not in routes
    assert '/api/integrations' not in routes
    assert '/api/webhooks/meta' not in routes
    assert '/api/instagram/reply' not in routes
    assert not any('campaign' in str(x) or 'webhook' in str(x) for x in routes)
    assert c.post('/api/instagram/reply',headers=h,json={'contact_id':1,'text':'Oi'}).status_code==404
    assert c.get('/api/integrations').status_code==404

def test_upgrade_legacy_contacts_deals(tmp_path,monkeypatch):
    db=tmp_path/'existing.sqlite'
    con=sqlite3.connect(db)
    con.executescript('''
    CREATE TABLE users(id INTEGER PRIMARY KEY,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,created_at TEXT NOT NULL);
    CREATE TABLE sessions(token_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL,csrf TEXT NOT NULL,expires_at TEXT NOT NULL);
    CREATE TABLE contacts(id INTEGER PRIMARY KEY,name TEXT NOT NULL,phone TEXT UNIQUE,instagram_id TEXT UNIQUE,tags TEXT NOT NULL DEFAULT '',ig_last_inbound TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
    CREATE TABLE activity(id INTEGER PRIMARY KEY,category TEXT NOT NULL,message TEXT NOT NULL,created_at TEXT NOT NULL);
    CREATE TABLE campaigns(id INTEGER PRIMARY KEY,name TEXT);
    ''')
    con.execute("INSERT INTO contacts(name,phone,tags,created_at,updated_at) VALUES ('Cliente Legado','+5511999887766','','2025-01-01','2025-01-01')")
    con.execute("INSERT INTO campaigns(name) VALUES ('Campanha Antiga')")
    con.commit();con.close()
    monkeypatch.setattr(backend,'DB_PATH',db)
    backend.initialize()
    with backend.transaction() as dbcon:
        row=dbcon.execute('SELECT name,proposal_status FROM contacts').fetchone()
        assert row['name']=='Cliente Legado' and row['proposal_status']=='pendente'
        assert dbcon.execute('SELECT COUNT(*) FROM campaigns').fetchone()[0]==1
        assert dbcon.execute('SELECT COUNT(*) FROM crm_deals').fetchone()[0]==0

def test_static_website_is_only_crm(c):
    html=c.get('/').text.lower()
    assert 'campanhas' not in html and 'disparo' not in html
    assert 'crm' in html and 'planos fechados' in html
