# GitHub → Render: Pulso Social CRM

## Segurança antes da publicação

- Crie um **repositório privado** no GitHub e conceda acesso ao aplicativo/integração do GitHub usado pelo ChatGPT nesse repositório.
- Não envie arquivos `.env`, dados de clientes nem `data/pulso.db`. Eles são ignorados por `.gitignore`.
- O banco em produção precisa ser PostgreSQL gerenciado. Configure backup e SSL no fornecedor.

## Deploy no Render

1. Faça upload dos arquivos deste projeto na raiz do repositório privado (não do ZIP como um único arquivo).
2. No Render, selecione **New → Blueprint**, conecte o repositório e escolha o arquivo `render.yaml`.
3. No serviço resultante, preencha `DATABASE_URL` usando a cadeia de conexão PostgreSQL do seu provedor.
4. O Render gera automaticamente `APP_SETUP_KEY`: abra Environment e copie o valor para usar apenas na criação do primeiro administrador. Não compartilhe a chave.
5. Use a URL HTTPS fornecida pelo Render. O app aceita `RENDER_EXTERNAL_URL` como origem quando `APP_ALLOWED_ORIGIN` não estiver definida.
6. Confira os logs de inicialização, acesse `/api/health`, conclua a configuração de administrador e teste o CRM.

## Atenções

- **Não foi publicado automaticamente**: o arquivo `render.yaml` apenas prepara a implantação.
- A conexão remota PostgreSQL ainda precisa ser testada no ambiente de hospedagem.
- Use 1 instância até validação de concorrência, migrações e backups.
- Configure rate limiting/WAF e backups antes de usar dados reais.
- Este CRM não possui funções de envio de mensagens.
