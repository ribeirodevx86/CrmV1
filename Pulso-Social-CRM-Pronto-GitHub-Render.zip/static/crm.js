'use strict';
/* CRM exclusivo de social media: propostas, clientes, planos e acompanhamento. */
let crmCache={contacts:[],summary:null};
let crmFilters={search:'',stage:'',proposal:''};
const crmStages={novo:'Novo lead',contatado:'Contatado',reuniao:'Reunião',proposta:'Proposta enviada',cliente:'Cliente',perdido:'Perdido'};
const crmProposals={pendente:'Aguardando resposta',aceitou:'Aceitou proposta',recusou:'Não aceitou'};
const crmBRL=(c)=>new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format((c||0)/100);
const crmDay=s=>s?String(s).split('-').reverse().join('/'):'—';
function crmBadge(p){return `<span class="crm-pill ${p==='aceitou'?'good':p==='recusou'?'no':'wait'}">${crmProposals[p]||'Pendente'}</span>`;}
function crmStat(label,value,note,icon){return `<div class="card"><div class="crm-stat-top"><span>${label}</span><div class="crm-icon">${icon}</div></div><div class="crm-number">${value}</div><div class="crm-note">${note}</div></div>`;}
async function crmView(){
  const [summary,contactData]=await Promise.all([api('/api/crm/summary'),api('/api/crm/contacts')]);
  crmCache.summary=summary;crmCache.contacts=contactData.items;
  q('#content').innerHTML=header('GESTÃO COMERCIAL · SOCIAL MEDIA',view==='pipeline'?'Funil de vendas':'Contatos e clientes','Acompanhe seus leads, propostas aceitas, contratos e oportunidades.',B('＋ Novo lead','crm-add','','primary'))+
    `<div class="crm-stats">${crmStat('Pessoas cadastradas',N(summary.total_contacts),'Sua base de contatos','♙')}${crmStat('Aceitaram a proposta',N(summary.accepted),'Aceite comercial registrado','✓')}${crmStat('Planos fechados',N(summary.deals_closed),'Todos os planos registrados','◈')}${crmStat('Mensalidade ativa',crmBRL(summary.active_monthly_cents),'Soma mensal dos planos ativos','↗')}</div>`+
    `<div class="crm-kpi-lower"><div class="card"><b>${N(summary.pending)}</b> <span class="crm-extra">propostas aguardando resposta</span></div><div class="card"><b>${N(summary.rejected)}</b> <span class="crm-extra">propostas não aceitas</span></div><div class="card"><b>${N(summary.followups_due)}</b> <span class="crm-extra">retornos pendentes ou vencidos</span></div></div>`+
    `<div class="card" style="margin-bottom:19px"><div class="crm-section-top"><div><h3 class="crm-block-title">Funil de relacionamento</h3><div class="crm-extra">Selecione uma etapa para filtrar os leads</div></div>${B('Limpar filtros','crm-reset','','small')}</div><div class="crm-pipeline">${summary.pipeline.map(p=>`<button class="crm-step" data-action="crm-stage" data-stage="${p.stage}"><small>${crmStages[p.stage]}</small><b>${N(p.count)}</b><div class="crm-line"><span style="width:${summary.total_contacts?p.count/summary.total_contacts*100:0}%"></span></div></button>`).join('')}</div></div>`+
    `<div class="card"><div class="crm-section-top"><div><h3 class="crm-block-title">Gerenciador de contatos</h3><div class="crm-extra">Negociação, aceite, planos e próximo acompanhamento</div></div><div class="crm-cardactions">${B('↓ Modelo CSV','crm-template','','small')}${B('↑ Importar CSV','crm-import','','small')}${B('↓ Exportar','crm-export','','small')}</div></div>`+
    `<div class="crm-filter"><input class="input" id="crm-search" placeholder="Buscar nome, empresa, telefone ou e-mail..." value="${esc(crmFilters.search)}"><select class="input" id="crm-stage"><option value="">Todas as etapas</option>${Object.entries(crmStages).map(([k,v])=>`<option value="${k}" ${crmFilters.stage===k?'selected':''}>${v}</option>`).join('')}</select><select class="input" id="crm-proposal"><option value="">Todas as respostas</option>${Object.entries(crmProposals).map(([k,v])=>`<option value="${k}" ${crmFilters.proposal===k?'selected':''}>${v}</option>`).join('')}</select></div>`+
    `<div id="crm-rows"></div></div>`;
  crmDrawRows();
}
function crmVisible(){let s=crmFilters.search.trim().toLocaleLowerCase('pt-BR');return crmCache.contacts.filter(c=>{
 const name=[c.name,c.company,c.email,c.phone,c.tags].join(' ').toLocaleLowerCase('pt-BR');
 return (!s||name.includes(s))&&(!crmFilters.stage||c.pipeline_stage===crmFilters.stage)&&(!crmFilters.proposal||c.proposal_status===crmFilters.proposal)
})}
function crmDrawRows(){let rows=crmVisible();let target=q('#crm-rows');if(!target)return;
 target.innerHTML=rows.length?`<div class="table-container"><table class="crm-tbl"><thead><tr><th>Contato / empresa</th><th>Etapa</th><th>Aceitou a proposta?</th><th>Planos fechados</th><th>Mensalidade ativa</th><th>Próximo retorno</th><th>Ações</th></tr></thead><tbody>${rows.map(c=>`<tr><td><b>${esc(c.name)}</b><span class="company-sub">${esc(c.company||c.email||c.phone||'Sem empresa')}</span></td><td>${esc(crmStages[c.pipeline_stage]||'Novo lead')}</td><td>${crmBadge(c.proposal_status)}</td><td><b>${N(c.closed_plans)}</b></td><td><span class="crm-money">${crmBRL(c.recurring_cents)}</span></td><td>${crmDay(c.next_followup_at)}</td><td><div class="crm-actionbar">${B('Abrir ficha','crm-detail',`data-id="${c.id}"`,'small')}${B('Editar','crm-edit',`data-id="${c.id}"`,'small')}</div></td></tr>`).join('')}</tbody></table></div>`:
  empty('◇',crmCache.contacts.length?'Nenhum resultado':'Seu CRM está vazio',crmCache.contacts.length?'Altere os filtros para visualizar outros contatos.':'Cadastre seu primeiro prospecto, registre o aceite de propostas e acompanhe cada plano fechado.',B('Adicionar primeiro lead','crm-add','','primary'));
 target.insertAdjacentHTML('beforeend',`<p class="tiny" style="margin:15px 0 0">${rows.length} contato(s) exibido(s) · ${crmCache.contacts.length} no banco · Valores em reais</p>`);
}
function crmContactForm(contact=null){const c=contact||{};let edit=!!contact;modal(edit?'Editar contato comercial':'Novo lead / contato comercial',
 `<div class="crm-hint">Registre a resposta à <b>proposta comercial</b> e avance o contato no funil. Organize cada negociação em um só lugar.</div><form id="crm-contact-form" data-id="${c.id||''}" class="formgrid" style="margin-top:17px">
 <label class="field">Nome do contato *<input class="input" name="name" required minlength="2" maxlength="140" value="${esc(c.name||'')}" placeholder="Ex.: Maria Oliveira"></label>
 <label class="field">Empresa / marca<input class="input" name="company" maxlength="160" value="${esc(c.company||'')}" placeholder="Ex.: Boutique Aurora"></label>
 <label class="field">Telefone<input class="input" name="phone" value="${esc(c.phone||'')}" placeholder="+5511999999999"></label>
 <label class="field">E-mail<input type="email" class="input" name="email" value="${esc(c.email||'')}" placeholder="contato@empresa.com"></label>
 <label class="field">Instagram (@perfil ou ID)<input class="input" name="instagram_id" value="${esc(c.instagram_id||'')}" placeholder="Ex.: @suaempresa"></label>
 <label class="field">Como chegou até você?<input class="input" name="lead_source" value="${esc(c.lead_source||'')}" placeholder="Indicação, Instagram, site..."></label>
 <label class="field">Etapa do funil<select class="input" name="pipeline_stage">${Object.entries(crmStages).map(([v,l])=>`<option value="${v}" ${c.pipeline_stage===v?'selected':''}>${l}</option>`).join('')}</select></label>
 <label class="field">Aceitou a proposta?<select class="input" name="proposal_status">${Object.entries(crmProposals).map(([v,l])=>`<option value="${v}" ${c.proposal_status===v?'selected':''}>${l}</option>`).join('')}</select></label>
 <label class="field">Data do próximo retorno<input type="date" class="input" name="next_followup_at" value="${esc(c.next_followup_at||'')}"></label>
 <label class="field">Etiquetas<input class="input" name="tags" maxlength="150" value="${esc(c.tags||'')}" placeholder="Nutrição, loja, salão..."></label>
 <label class="field wide">Observações comerciais<textarea name="crm_description" maxlength="3000" placeholder="Objetivo, necessidades, orçamento, preferências...">${esc(c.crm_description||'')}</textarea></label>
 <div class="field wide">${actions(`<button type="submit" class="button primary">${edit?'Salvar alterações':'Cadastrar contato'}</button>`)}</div></form>`);
}
async function crmDetail(id){let data=await api(`/api/crm/contacts/${id}`);let c=data.contact;const plans=data.deals,hist=data.history;
 modal('Ficha do contato',`<div class="crm-detail-header"><div class="crm-circle">${esc(c.name.trim().split(' ').map(w=>w[0]).slice(0,2).join('').toUpperCase())}</div><div><b style="font-size:16px">${esc(c.name)}</b><p>${esc(c.company||'Pessoa física / empresa não informada')}</p></div></div>
 <div class="crm-actions">${B('Editar contato','crm-edit',`data-id="${id}"`,'small')}${B('Excluir contato','crm-delete',`data-id="${id}"`,'small danger')}${B('＋ Plano fechado','crm-add-deal',`data-id="${id}"`,'small primary')}${B('＋ Registrar interação','crm-add-history',`data-id="${id}"`,'small')}</div>
 <div class="crm-rows"><div class="crm-row"><span>Aceite da proposta comercial</span>${crmBadge(c.proposal_status)}</div><div class="crm-row"><span>Etapa no funil</span><strong>${crmStages[c.pipeline_stage]||'—'}</strong></div><div class="crm-row"><span>WhatsApp</span><strong>${esc(c.phone||'Não informado')}</strong></div><div class="crm-row"><span>E-mail</span><strong>${esc(c.email||'Não informado')}</strong></div><div class="crm-row"><span>Instagram</span><strong>${esc(c.instagram_id||'Não informado')}</strong></div><div class="crm-row"><span>Origem</span><strong>${esc(c.lead_source||'—')}</strong></div><div class="crm-row"><span>Próximo retorno</span><strong>${crmDay(c.next_followup_at)}</strong></div></div>
 ${c.crm_description?`<div class="crm-hint" style="margin-top:16px;white-space:pre-wrap">${esc(c.crm_description)}</div>`:''}
 <div class="crm-divider"></div><div class="crm-section-top"><h3 class="crm-block-title">Planos fechados <span class="crm-pill good">${plans.length}</span></h3>${B('＋ Registrar plano','crm-add-deal',`data-id="${id}"`,'small')}</div>
 ${plans.length?plans.map(p=>`<div class="crm-row"><div><b>${esc(p.plan_name)}</b><div class="crm-extra">${crmDay(p.closed_date)} · ${esc(({ativo:'Ativo',concluido:'Concluído',cancelado:'Cancelado'})[p.status]||p.status)}</div></div><div style="text-align:right"><strong class="crm-money">${crmBRL(p.monthly_cents)}/mês</strong><div style="margin-top:5px">${B('Editar','crm-edit-deal',`data-id="${p.id}" data-contact="${id}"`,'small')}${B('Excluir','crm-delete-deal',`data-id="${p.id}" data-contact="${id}"`,'small danger')}</div></div></div>`).join(''):'<p class="crm-extra">Nenhum plano fechado registrado ainda.</p>'}
 <div class="crm-divider"></div><div class="crm-section-top"><h3 class="crm-block-title">Histórico de relacionamento</h3>${B('＋ Anotação','crm-add-history',`data-id="${id}"`,'small')}</div>
 ${hist.length?hist.map(h=>`<div class="crm-event"><div class="crm-event-dot"></div><div><p>${esc(h.description)}</p><small>${datestr(h.created_at)}</small></div></div>`).join(''):'<p class="crm-extra">Ainda não há interações registradas.</p>'}
 <div class="crm-detail-footer">${B('Fechar ficha','close-modal')}</div>`);
}
function crmDealForm(id,deal=null){const dt=new Date().toISOString().slice(0,10);const p=deal||{};modal(deal?'Editar plano fechado':'Registrar plano fechado',`<div class="crm-hint">Cada plano registrado aumenta o total de fechamentos. Ao confirmar um plano, o contato passa para <b>Cliente</b> e a proposta fica marcada como <b>Aceitou</b>. O registro comercial é independente de outros canais.</div>
 <form id="crm-deal-form" data-id="${id}" data-deal="${p.id||''}" class="formgrid" style="margin-top:17px"><label class="field wide">Nome do plano contratado *<input class="input" required minlength="2" maxlength="160" name="plan_name" value="${esc(p.plan_name||'')}" placeholder="Gestão de Instagram, tráfego pago, pacote mensal..."></label>
 <label class="field">Valor mensal em reais (R$)<input class="input" type="number" min="0" max="100000000" step="0.01" name="monthly_value" value="${p.id?(p.monthly_cents/100).toFixed(2):'0'}" required></label>
 <label class="field">Situação do plano<select class="input" name="status"><option value="ativo" ${p.status==='ativo'?'selected':''}>Ativo</option><option value="concluido" ${p.status==='concluido'?'selected':''}>Concluído</option><option value="cancelado" ${p.status==='cancelado'?'selected':''}>Cancelado</option></select></label>
 <label class="field">Data do fechamento<input class="input" type="date" required name="closed_date" value="${esc(p.closed_date||dt)}"></label><label class="field wide">Observações<textarea name="remarks" maxlength="1500" placeholder="Serviços, duração e condições acordadas...">${esc(p.remarks||'')}</textarea></label>
 <div class="field wide">${actions(`<button type="submit" class="button primary">${deal?'Salvar plano':'Registrar fechamento'}</button>`)}</div></form>`)}
function crmHistoryForm(id){modal('Registrar interação',`<form id="crm-history-form" class="formgrid" data-id="${id}"><label class="field wide">O que aconteceu? *<textarea required minlength="2" maxlength="2000" name="description" placeholder="Ex.: reunião realizada, orçamento enviado, cliente pediu retorno na sexta..."></textarea></label><div class="field wide">${actions('<button class="button primary" type="submit">Salvar interação</button>')}</div></form>`)}
function crmImportModal(){modal('Importar contatos para o CRM',`<div class="crm-hint">Colunas: <b>nome, telefone, email, empresa, origem, etapa, proposta, retorno, etiquetas, observacoes</b>. Use a planilha para gerenciar seus contatos e clientes, com o histórico comercial. A conta de Instagram é opcional.</div><form id="crm-import-form" class="formgrid" style="margin-top:18px"><label class="field wide">Arquivo CSV de até 2 MB<input class="input" type="file" name="file" required accept=".csv,text/csv"></label><div class="field wide">${actions('<button class="button primary" type="submit">Importar CSV</button>')}</div></form>`)}

document.addEventListener('click',async e=>{
 let b=e.target.closest('[data-action^="crm-"]');if(!b)return;
 let action=b.dataset.action,id=Number(b.dataset.id||0);
 try{
  if(action==='crm-add')crmContactForm();
  if(action==='crm-delete'){if(confirm('Excluir permanentemente este contato e suas anotações? Contatos com planos registrados precisam ter os planos removidos primeiro.')){await del(`/api/crm/contacts/${id}`);closeModal();await render();notify('Contato excluído do CRM.')}}
  if(action==='crm-edit'){let c=await api(`/api/crm/contacts/${id}`);crmContactForm(c.contact)}
  if(action==='crm-detail')await crmDetail(id);
  if(action==='crm-add-deal')crmDealForm(id);
  if(action==='crm-edit-deal'){let detail=await api(`/api/crm/contacts/${Number(b.dataset.contact)}`);let p=detail.deals.find(x=>x.id===id);if(p)crmDealForm(Number(b.dataset.contact),p);}
  if(action==='crm-add-history')crmHistoryForm(id);
  if(action==='crm-delete-deal'){if(confirm('Excluir este registro de plano fechado? A contagem e as métricas serão recalculadas.')){await del(`/api/crm/deals/${id}`);await render();await crmDetail(Number(b.dataset.contact));notify('Registro de plano excluído.')}}
  if(action==='crm-stage'){crmFilters.stage=b.dataset.stage;let f=q('#crm-stage');if(f)f.value=crmFilters.stage;crmDrawRows()}
  if(action==='crm-reset'){crmFilters={search:'',stage:'',proposal:''};await render()}
  if(action==='crm-template')saveCsv('modelo-crm-social-media.csv',[['nome','telefone','email','empresa','origem','etapa','proposta','retorno','etiquetas','observacoes']]);
  if(action==='crm-import')crmImportModal();
  if(action==='crm-export'){
   let rows=crmVisible();saveCsv('crm-social-media.csv',[['nome','empresa','telefone','email','etapa','aceitou_proposta','planos_fechados','mensalidade_ativa_r$','proximo_retorno','origem','observacoes'],...rows.map(c=>[c.name,c.company,c.phone,c.email,c.pipeline_stage,c.proposal_status,c.closed_plans,(c.recurring_cents/100).toFixed(2).replace('.',','),c.next_followup_at,c.lead_source,c.crm_description])]);notify('Contatos exportados em CSV.');}
 }catch(err){errorText(err)}
});
document.addEventListener('input',e=>{if(e.target.id==='crm-search'){crmFilters.search=e.target.value;crmDrawRows()}});
document.addEventListener('change',e=>{if(e.target.id==='crm-stage'){crmFilters.stage=e.target.value;crmDrawRows()}if(e.target.id==='crm-proposal'){crmFilters.proposal=e.target.value;crmDrawRows()}});
document.addEventListener('submit',async e=>{
 if(!['crm-contact-form','crm-deal-form','crm-history-form','crm-import-form'].includes(e.target.id))return;
 e.preventDefault();let f=e.target,id=Number(f.dataset.id||0),form=new FormData(f),d=Object.fromEntries(form);
 try{
  if(f.id==='crm-contact-form'){
   if(!d.phone&&!d.email&&!d.instagram_id)throw new Error('Informe pelo menos telefone, e-mail ou Instagram ID.');
   if(id)await api(`/api/crm/contacts/${id}`,{method:'PUT',body:JSON.stringify(d)});else await post('/api/crm/contacts',d);
   closeModal();await render();notify(id?'Contato atualizado com sucesso.':'Contato cadastrado no CRM.');
  }
  if(f.id==='crm-deal-form'){if(f.dataset.deal)await api(`/api/crm/deals/${f.dataset.deal}`,{method:'PUT',body:JSON.stringify(d)});else await post(`/api/crm/contacts/${id}/deals`,d);await render();await crmDetail(id);notify('Plano salvo. Os indicadores foram atualizados.');}
  if(f.id==='crm-history-form'){await post(`/api/crm/contacts/${id}/history`,d);await render();await crmDetail(id);notify('Interação registrada no histórico.');}
  if(f.id==='crm-import-form'){
    let file=d.file;if(!file||file.size>2000000)throw new Error('Escolha um CSV de até 2 MB.');
    let result=await post('/api/crm/import',{csv:await file.text()});closeModal();await render();notify(`${result.added} adicionados, ${result.duplicates} duplicados, ${result.invalid} inválidos. Importação concluída.`);
  }
 }catch(err){errorText(err)}
});
