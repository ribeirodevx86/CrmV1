'use strict';
const q=(s,root=document)=>root.querySelector(s);
const qa=(s,root=document)=>[...root.querySelectorAll(s)];
const esc=(v)=>String(v??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const datestr=s=>s?new Date(s).toLocaleString('pt-BR',{dateStyle:'short',timeStyle:'short'}):'—';
const N=v=>Number(v||0).toLocaleString('pt-BR');
let session=null,setup=false,view='dashboard',toastTimeout=null;
const viewNames={dashboard:'Visão geral',contacts:'Contatos e clientes',pipeline:'Funil de vendas',plans:'Planos fechados',followups:'Retornos e tarefas',reports:'Relatórios'};
async function api(url,opt={}){
  const options={credentials:'same-origin',...opt,headers:{...(opt.body?{'Content-Type':'application/json'}:{}),...(session&&opt.method&&opt.method!=='GET'?{'X-CSRF-Token':session.csrf}:{}),...(opt.headers||{})}};
  const res=await fetch(url,options);let data;try{data=await res.json()}catch{data={detail:'Resposta inválida do servidor.'}}
  if(!res.ok){if(res.status===401&&session){session=null;showAuth(false)}throw new Error(typeof data.detail==='string'?data.detail:JSON.stringify(data.detail||data.error||'Falha na operação.'))}
  return data;
}
const post=(path,obj={})=>api(path,{method:'POST',body:JSON.stringify(obj)});
const del=path=>api(path,{method:'DELETE'});
function notify(text){const n=q('#toast');n.textContent=text;n.classList.remove('hidden');clearTimeout(toastTimeout);toastTimeout=setTimeout(()=>n.classList.add('hidden'),4600)}
function errorText(err){notify(err?.message||'Não foi possível concluir. Confira seus dados.')}
function header(kicker,title,sub,button=''){return `<div class="section-head"><div><div class="micro">${kicker}</div><h1>${title}</h1><p>${sub}</p></div>${button}</div>`}
const B=(text,action,extra='',style='')=>`<button class="button ${style}" data-action="${action}" ${extra}>${text}</button>`;
function empty(icon,title,desc,act=''){return `<div class="empty"><div class="empty-icon">${icon}</div><b>${title}</b><p>${desc}</p>${act}</div>`}
function modal(title,html){q('#modal-title').textContent=title;q('#modal-body').innerHTML=html;q('#modal-overlay').classList.remove('hidden')}
function closeModal(){q('#modal-overlay').classList.add('hidden');q('#modal-body').innerHTML=''}
function actions(extra=''){return `<div class="form-actions">${B('Cancelar','close-modal')}${extra}</div>`}
function saveCsv(name,rows){let csv=rows.map(r=>r.map(s=>'"'+String(s??'').replaceAll('"','""')+'"').join(';')).join('\r\n');const blob=new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8'});let u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),600)}
function showAuth(isSetup){q('#shell').classList.add('hidden');q('#auth').classList.remove('hidden');setup=isSetup;q('#auth-title').textContent=isSetup?'Crie seu administrador':'Bem-vindo de volta';q('#auth-description').textContent=isSetup?'Configure o acesso à sua base de contatos.':'Entre para gerenciar seus clientes e contratos.';q('#auth-button').textContent=isSetup?'Criar administrador →':'Entrar no CRM →';q('#setup-key-label').classList.toggle('hidden',!isSetup);q('#auth-error').classList.add('hidden');q('#auth-form').reset()}
function showShell(){q('#auth').classList.add('hidden');q('#shell').classList.remove('hidden');q('#avatar').textContent=(session?.email||'P')[0].toUpperCase()}
async function boot(){try{let s=await api('/api/setup');if(s.required){showAuth(true);return}session=await api('/api/me');showShell();await render()}catch(e){try{let s=await api('/api/setup');showAuth(s.required)}catch(err){q('body').innerHTML=`<div class="empty"><b>Não foi possível conectar ao servidor</b><p>${esc(err.message)}</p></div>`}}}
function navigate(target){if(!viewNames[target])return;view=target;qa('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===target));q('.sidebar').classList.remove('open');render()}
async function render(){q('#page-name').textContent=viewNames[view];q('#content').innerHTML='<div class="empty">Carregando seu CRM…</div>';try{if(view==='dashboard')await crmDashboard();else if(view==='contacts'||view==='pipeline')await crmView();else if(view==='plans')await crmPlans();else if(view==='followups')await crmFollowups();else if(view==='reports')await crmReports()}catch(e){q('#content').innerHTML=header('ATENÇÃO','Não foi possível carregar',esc(e.message))+B('Tentar novamente','reload','','primary')}}
q('#auth-form').addEventListener('submit',async e=>{e.preventDefault();let d=Object.fromEntries(new FormData(e.target));try{if(setup){await post('/api/setup',d);showAuth(false);notify('Administrador criado! Agora faça login.')}else{session=await post('/api/login',{email:d.email,password:d.password});showShell();await render()}}catch(err){q('#auth-error').textContent=err.message;q('#auth-error').classList.remove('hidden')}});
q('#logout').addEventListener('click',async()=>{try{await post('/api/logout')}catch{}session=null;showAuth(false)});
q('#mobile-menu').addEventListener('click',()=>q('.sidebar').classList.toggle('open'));
q('#close-modal').addEventListener('click',closeModal);
q('#modal-overlay').addEventListener('click',e=>{if(e.target.id==='modal-overlay')closeModal()});
qa('[data-view]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.view)));
document.addEventListener('click',e=>{let b=e.target.closest('[data-action]');if(!b||b.dataset.action.startsWith('crm-'))return;if(b.dataset.action==='close-modal')closeModal();if(b.dataset.action==='reload')render()});
// CRM module registers its handlers next; wait until all scripts load.
window.addEventListener('load',boot);
