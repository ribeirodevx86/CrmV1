# Publicar Pulso Social CRM v3 na internet (FastAPI + PostgreSQL)

Esta versão mantém o painel HTML/CSS/JS e FastAPI e remove qualquer função de disparo de mensagens. O banco na produção deve ser PostgreSQL gerenciado; SQLite fica apenas para uso local.

## Recomendação: Render Web Service + PostgreSQL gerenciado

1. Crie uma conta em https://github.com e um repositório **privado** (`pulso-social-crm`). Extraia o ZIP e envie apenas a pasta do projeto para o repositório. **Nunca envie `.env`, `data/pulso.db`, senhas ou exports de clientes para o GitHub.**
2. Crie um PostgreSQL gerenciado (Render Postgres, Neon ou Supabase). Copie a URL de conexão *server-side* no formato `postgresql://usuario:senha@host:5432/banco?sslmode=require`. Não use chaves Supabase de cliente como senha PostgreSQL.
3. Em https://dashboard.render.com crie um serviço **Web Service** a partir desse repositório. Escolha **Docker** como runtime e defina o diretório raiz como a pasta do projeto, caso o repositório contenha outras pastas.
4. Configure as variáveis de ambiente no painel de hospedagem:
   - `DATABASE_URL`: URL de conexão PostgreSQL (SSL habilitado, quando exigido pelo provedor)
   - `APP_SETUP_KEY`: chave secreta longa, gerada por você (pelo menos 32 caracteres aleatórios)
   - `COOKIE_SECURE=true`
   - `APP_ALLOWED_ORIGIN=https://SEU-ENDERECO.onrender.com` (troque pelo endereço exato publicado, sem barra final)
5. Faça deploy. Ao iniciar, o servidor cria as tabelas no PostgreSQL sem inserir dados fictícios. O endpoint `/api/health` responde `ok` e `messaging:false`.
6. Abra a URL HTTPS, crie **a primeira conta de administrador** usando a mesma `APP_SETUP_KEY`, e depois faça login.
7. Teste criar contato, editar proposta e cadastrar um plano. Faça logout e login novamente. Confirme que os dados continuam aparecendo após novo deploy/restart.

**Atenção:** planos gratuitos podem hibernar; confira o suporte a banco permanente e políticas de backup do provedor. Configure backup automático no provedor PostgreSQL. Sempre use HTTPS. Não exponha a URL do banco ou as variáveis secretas.

## Arquivos relevantes

- `Dockerfile`: imagem executável com Uvicorn e FastAPI.
- `postgres_store.py`: camada PostgreSQL para as consultas existentes do CRM.
- `.env.production.example`: variáveis necessárias para produção.
- `requirements.txt`: dependências, incluindo psycopg.
- `static/`: painel preservado.
- `tests/`: testes de regressão SQLite/local.

## Rodar localmente como antes

Sem `DATABASE_URL` o aplicativo mantém SQLite com o fluxo antigo: crie `.env` usando `.env.example` e execute `iniciar-windows.bat`. Os arquivos de produção não modificam seu banco SQLite local.

## Levar dados do SQLite antigo para produção

O PostgreSQL novo começa **vazio**. Dados do arquivo `data/pulso.db` NÃO são copiados automaticamente. Não publique o banco SQLite no GitHub. Para migrar registros antigos, exporte contatos CSV no aplicativo antigo e importe pelo painel novo. A importação CSV contempla contatos e campos comerciais, mas **não migra automaticamente** histórico, planos ou usuários. Para esses dados é necessário um procedimento de migração adicional com backup, conferência de valores e testes, que não está incluído neste pacote.

## Segurança / pendências de produção

- Há senha com PBKDF2, sessão HttpOnly, Secure cookie quando `COOKIE_SECURE=true`, verificação de token CSRF e regra de origem configurável.
- Esta é uma aplicação de **um único administrador inicial**; não é um sistema multiusuário com papéis ou acesso granular.
- Antes de expor dados sensíveis de clientes, implemente ou configure limites de tentativas de login na borda (WAF/rate limiting), backups, monitoramento, política de retenção e gestão de contas.
- O adaptador PostgreSQL foi preparado para as consultas do app, mas **a integração fim a fim com um servidor PostgreSQL remoto não pôde ser executada neste ambiente**. Faça os testes indicados acima com banco de teste antes de tratar a implantação como pronta para uso comercial.
- Mantenha apenas **1 worker/instância** até revisar concorrência, migrações e sessões. Garanta que o provedor reinicie o container e não execute `uvicorn --reload` em produção.
