#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
[ -e .env ] || cp .env.example .env
[ -d .venv ] || python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
printf '\nAbra http://127.0.0.1:8000 no navegador.\n'
python executar.py
